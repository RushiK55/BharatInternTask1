package com.rushi.todo_List.database.parameter;

public class Parameters {
    //the Main Paramter For the For The Database
    public static final int DB_VERSION = 1;
    public static final String DB_NAME = "TodoList";
    public static final String TABLE_NAME = "TodoListTask";

    public static final String KEY_ID = "id";
    public static final String KEY_TASK = "task";

}
